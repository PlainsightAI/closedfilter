import logging
import os
import json
import re
import easyocr
import pytesseract
from enum import Enum
from filter_runtime.filter import FilterConfig, Filter, Frame
from dotenv import load_dotenv
load_dotenv()

__all__ = ['FilterOpticalCharacterRecognitionConfig', 'FilterOpticalCharacterRecognition']

logger = logging.getLogger(__name__)

SKIP_OCR_FLAG = 'skip_ocr'

class OCREngine(Enum):
    """
    Enumeration of supported OCR engines.
    
    Attributes:
        TESSERACT: Uses Tesseract OCR engine
        EASYOCR: Uses EasyOCR engine
    """
    TESSERACT = 'tesseract'
    EASYOCR = 'easyocr'

    @classmethod
    def from_str(cls, value: str) -> "OCREngine":
        """
        Convert a string to an OCREngine enum value.
        
        Args:
            value (str): String representation of the OCR engine
            
        Returns:
            OCREngine: Corresponding enum value
            
        Raises:
            ValueError: If the string doesn't match any enum value
        """
        try:
            return cls(value.strip().lower())
        except ValueError:
            raise ValueError(
                f"Invalid mode: {value!r}. Expected one of: {[s.value for s in cls]}"
            )

class FilterOpticalCharacterRecognitionConfig(FilterConfig):
    """
    Configuration for the OCR filter.
    
    Attributes:
        debug (bool): Enable debug logging (default: False)
        ocr_engine (OCREngine): OCR engine to use (default: EASYOCR)
        output_json_path (str): Path to save OCR results (default: './output/ocr_results.json')
        ocr_language (list[str]): List of languages for OCR (default: ['en'])
        tesseract_cmd (str): Path to Tesseract executable
        forward_ocr_texts (bool): Forward OCR results in frame metadata (default: True)
        write_output_file (bool): Write results to output file (default: True)
        topic_pattern (str): Regex pattern to match topic names (default: None)
    """
    debug: bool = False
    ocr_engine: OCREngine = OCREngine.EASYOCR.value
    output_json_path: str = './output/ocr_results.json'
    ocr_language: list[str] = ['en']
    tesseract_cmd: str = f"{os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'bin', 'tesseract', 'tesseract.AppImage'))}"
    forward_ocr_texts: bool = True
    write_output_file: bool = True
    topic_pattern: str = None  # Regex pattern to match topic names

class FilterOpticalCharacterRecognition(Filter):
    """
    A filter that performs Optical Character Recognition (OCR) on input frames.
    
    This filter can:
    1. Process multiple input topics matching a specified pattern
    2. Use either Tesseract or EasyOCR engine for text extraction
    3. Support multiple languages for OCR
    4. Forward OCR results in frame metadata
    5. Write results to a JSON file
    
    Configuration:
    See FilterOpticalCharacterRecognitionConfig for available optionsw
        
    Processing:
        1. Filters input topics based on pattern if specified
        2. Performs OCR on each selected frame
        3. Stores results in frame metadata
        4. Writes results to output file if configured
    """

    @classmethod
    def normalize_config(cls, config: FilterOpticalCharacterRecognitionConfig):
        """
        Normalize and validate the filter configuration.
        
        Args:
            config (FilterOpticalCharacterRecognitionConfig): Input configuration
            
        Returns:
            FilterOpticalCharacterRecognitionConfig: Normalized configuration
            
        Raises:
            ValueError: If configuration values are invalid
        """
        config = FilterOpticalCharacterRecognitionConfig(super().normalize_config(config))
        env_mapping = {
            "debug": bool,
            "ocr_engine": str,
            "output_json_path": str,
            "ocr_language": list,  # parsed from comma-separated env var
            "tesseract_cmd": str,
            "forward_ocr_texts": bool,
            "write_output_file": bool,
            "topic_pattern": str,
        }

        for key, expected_type in env_mapping.items():
            env_key = f"FILTER_{key.upper()}"
            env_val = os.getenv(env_key)
            if env_val is not None:
                if expected_type is bool:
                    setattr(config, key, env_val.strip().lower() == "true")
                elif expected_type is list:
                    setattr(config, key, [lang.strip() for lang in env_val.split(",")])
                else:
                    setattr(config, key, env_val.strip())

        # Validate debug mode
        if isinstance(config.debug, str):
            true_or_false = ['true', 'false']
            if config.debug.strip().lower() not in true_or_false:
                raise ValueError(
                    f"Invalid debug mode: {config.debug!r}. Expected one of: {true_or_false}"
                )
            config.debug = config.debug.lower() == "true"
        elif not isinstance(
            config.debug, bool
        ):  # Allow booleans without raising an error
            raise ValueError(
                f"Invalid debug mode: {config.debug}. It should be True or False."
            )

        # Validate engine choice
        if not isinstance(config.ocr_engine, str):
            raise ValueError(
                f"Invalid ocr engine choice: {config.ocr_engine}. Must be one of {[name.lower() for name in OCREngine._member_names_]}"
            )
        config.ocr_engine = OCREngine.from_str(
            config.ocr_engine
        )  # throws value error for invalid choices

        if not isinstance(config.ocr_engine, OCREngine):
            raise ValueError(f"Invalid OCR engine. Choose from {[e.value for e in OCREngine]}.")
        if not isinstance(config.ocr_language, list):
            raise ValueError("Language must be a list of language codes. i.e. ['en', 'zh']")
        
        return config

    def setup(self, config: FilterOpticalCharacterRecognitionConfig):
        """
        Initialize the OCR filter with configuration.
        
        Args:
            config (FilterOpticalCharacterRecognitionConfig): Filter configuration
            
        Raises:
            ValueError: If configuration is invalid
            Exception: If output file cannot be opened
        """
        logger.info("===========================================")
        logger.info(f"FilterOpticalCharacterRecognition setup: {config}")
        logger.info("===========================================")

        self.ocr_engine = config.ocr_engine
        self.output_json_path = config.output_json_path
        self.debug = config.debug
        self.language = config.ocr_language
        self.forward_ocr_texts = config.forward_ocr_texts
        self.write_output_file = config.write_output_file
        self.topic_pattern = config.topic_pattern
        self.output_file = None
        
        if self.topic_pattern:
            try:
                self.topic_regex = re.compile(self.topic_pattern)
                logger.info(f"Using topic pattern: {self.topic_pattern}")
            except re.error as e:
                logger.error(f"Invalid regex pattern '{self.topic_pattern}': {e}")
                raise ValueError(f"Invalid regex pattern: {e}")
        else:
            self.topic_regex = None
            logger.info("No topic pattern specified, will process all topics")
            
        if self.ocr_engine == OCREngine.TESSERACT:
            pytesseract.pytesseract.tesseract_cmd = config.tesseract_cmd
        elif self.ocr_engine == OCREngine.EASYOCR:
            self.easyocr_reader = easyocr.Reader(self.language)
        else:
            raise ValueError("Invalid OCR engine selection.")
        
        if config.debug:
            logger.setLevel(logging.DEBUG)

        if self.write_output_file:
            os.makedirs(os.path.dirname(self.output_json_path), exist_ok=True)
            try:
                self.output_file = open(self.output_json_path, 'a', encoding='utf-8')
            except Exception as e:
                logger.error(f"Failed to open output JSON file: {e}")
                raise

    def shutdown(self):
        """
        Clean up resources when the filter is shutting down.
        
        Closes the output file if it was opened and logs the shutdown status.
        """
        if self.output_file:
            self.output_file.close()
            logger.info("Closed output JSON file.")
        if self.write_output_file:
            logger.info(f"OCR Filter shutting down. Processed data saved at {self.output_json_path}")
        else:
            logger.info("OCR Filter shutting down. No output file was written.")

    def process(self, frames: dict[str, Frame]):
        for topic, frame in frames.items():
            if self.topic_regex and not self.topic_regex.search(topic):
                logger.debug(f"Skipping OCR for topic {topic} due to topic_regex mismatch")
                continue  # skip topics that don't match

            frame_meta = frame.data.get('meta', {})
            if frame_meta.get(SKIP_OCR_FLAG, False):
                logger.debug(f"Skipping OCR for topic {topic} due to skip_ocr flag")
                continue

            image = frame.rw_bgr.image
            frame_id = frame_meta.get('id', None)
            texts = []

            if self.ocr_engine == OCREngine.TESSERACT:
                result = pytesseract.image_to_string(image).strip()
                if len(result) > 0:
                    texts = result.split('\n')
            elif self.ocr_engine == OCREngine.EASYOCR:
                texts = self.easyocr_reader.readtext(image, detail=0)
            else:
                raise ValueError("Invalid OCR engine selected.")

            logger.info(f"Topic {topic} (Frame {frame_id}) OCR Text: {texts}")

            if self.forward_ocr_texts:
                frame.data.setdefault('meta', {})['ocr_texts'] = texts

            if self.output_file:
                ocr_result = {
                    "topic": topic,
                    "frame_id": frame_id,
                    "texts": texts
                }
                self.output_file.write(json.dumps(ocr_result, ensure_ascii=False) + '\n')
                self.output_file.flush()

        return frames

if __name__ == '__main__':
    FilterOpticalCharacterRecognition.run()
