import logging
import requests
from datetime import datetime, timezone
from json import dumps as json_dumps, loads as json_loads
from typing import NamedTuple

from .telemetry import TelemetryConfig, Telemetry
from ..logging import LogCategory
from ..rolllog import RollLog

__all__ = ['TelemetryGCConfig', 'TelemetryGC']

logger = logging.getLogger(__name__)

metric_types = {
    'fps':          ('custom.googleapis.com/filter/framerate/fps', float),
    'cpu':          ('custom.googleapis.com/filter/cpu/utilization', float),
    'mem':          ('custom.googleapis.com/filter/system/memory/used_gb', float),
    'lat_in':       ('custom.googleapis.com/filter/latency/ms', float),
    'lat_out':      ('custom.googleapis.com/filter/latency/ms', float),
    'gpu0':         ('custom.googleapis.com/filter/gpu/utilization', float),
    'gpu0_mem':     ('custom.googleapis.com/filter/gpu/memory/used_gb', float),
    'gpu1':         ('custom.googleapis.com/filter/gpu/utilization', float),
    'gpu1_mem':     ('custom.googleapis.com/filter/gpu/memory/used_gb', float),
    'gpu2':         ('custom.googleapis.com/filter/gpu/utilization', float),
    'gpu2_mem':     ('custom.googleapis.com/filter/gpu/memory/used_gb', float),
    'gpu3':         ('custom.googleapis.com/filter/gpu/utilization', float),
    'gpu3_mem':     ('custom.googleapis.com/filter/gpu/memory/used_gb', float),
    'gpu4':         ('custom.googleapis.com/filter/gpu/utilization', float),
    'gpu4_mem':     ('custom.googleapis.com/filter/gpu/memory/used_gb', float),
    'gpu5':         ('custom.googleapis.com/filter/gpu/utilization', float),
    'gpu5_mem':     ('custom.googleapis.com/filter/gpu/memory/used_gb', float),
    'gpu6':         ('custom.googleapis.com/filter/gpu/utilization', float),
    'gpu6_mem':     ('custom.googleapis.com/filter/gpu/memory/used_gb', float),
    'gpu7':         ('custom.googleapis.com/filter/gpu/utilization', float),
    'gpu7_mem':     ('custom.googleapis.com/filter/gpu/memory/used_gb', float),
    'uptime_count': ('custom.googleapis.com/filter/uptime/seconds', int),
    'frame_count':  ('custom.googleapis.com/filter/processed/frames', int),
    'megapx_count': ('custom.googleapis.com/filter/processed/megapixels', float),
}


class TelemetryGCConfig(TelemetryConfig):
    pass


class TelemetryGC(Telemetry):
    """Telemetry for Google Cloud Monitoring and Google Storage. IMPORTANT! You MUST have the
    'GOOGLE_APPLICATION_CREDENTIALS' environment variable set to a service account .json file which has access to the
    destinations you are sending to.

    config:
        outputs:
            These outputs follow the pattern of the base Telemetry class for the semicolon ';' delimited logs and
            metrics sources. The destinations defined by this filter are of the gcm:// type for sending to Google
            Cloud Metrics to be viewable directly with the Google web UI and also gs:// to be able to send files
            directly to google buckets.

            gcm:// destinations take the format of 'gcm://project_id/pipeline_id' and the metrics will be tagged with
            the `pipeline_id' as well as the 'filter_id'.

            gs:// destinations are just destination buckets where individual filters with their logs and metrics will
            create subdirectories. The suggested format is 'gs://.../customer_id/pipeline_id'.

    Example `outputs` (spaces are purely for readability):
        "gcm://monitoring-433118/pipeline_1" - Send all logs and metrics from all filters in "pipeline_1" to Google
            Cloud Monitoring project "monitoring-433118".

        "gcm://monitoring-433118/pipeline_1 ; myfilter" - Send all logs and metrics from filter "myfilter" in
            "pipeline_1" to Google Cloud Monitoring project "monitoring-433118".

        "gcm://monitoring-433118/pipeline_1 ; myfilter / logs" - Send all logs from filter "myfilter" in "pipeline_1" to
            Google Cloud Monitoring project "monitoring-433118".

        "gcm://monitoring-433118/pipeline_1 ; myfilter / metrics" - Send all metrics from filter "myfilter" in
            "pipeline_1" to Google Cloud Monitoring project "monitoring-433118".

        "gcm://monitoring-433118/pipeline_1 ; myfilter / logs / metrics.cpu|gpu0" - Send all logs and CPU or GPU metrics
            from filter "myfilter" in "pipeline_1" to Google Cloud Monitoring project "monitoring-433118".

        "gcm://monitoring-433118/pipeline_1 ; myfilter/logs ; my_other_filter/metrics.plainsight" - Send all logs and
            plainsight metrics from filter "myfilter" in "pipeline_1" to Google Cloud Monitoring project
            "monitoring-433118".

        "gcm://monitoring-433118/pipeline_1 ; my* / metrics, gcm://monitoring-other/pipeline_1 ; *end / logs" - Send
            all metrics from all filters in "pipeline_1" starting with the characters "my" to  to Google Cloud
            Monitoring project "monitoring-433118" and all logs from all filters ending with characters "end" to Google
            Cloud Monitoring project "monitoring-other".

        "gs://customer_123/pipeline_1 ; my* / metrics.special*" - Send all metrics that start with the characters
            "special" from all filters that start with the characters "my" to the Google Storage bucket
            "customer_123/pipeline_1".

        "gs://customer_123/pipeline_1 ; * / logs / metrics.cpu, gcm://monitoring-433118/pipeline_2" - Send all logs and
            the CPU metric from all filters in "pipeline_1" to the Google Storage bucket "customer_123/pipeline_1" and
            all logs and metrics from all filters in "pipeline_2" to Google Cloud Monitoring project
            "monitoring-433118".
    """

    class OutputGCM(NamedTuple):
        project_name: str
        pipeline_id:  str
        metric_types: dict[str, tuple[str, type]]

    class OutputGS(NamedTuple):
        bucket:   'google.cloud.storage.bucket.Bucket'
        blobpath: str


    def create_metric(self, project_name, type, unit, display_name, description=None, is_int=False, is_count=False):
        try:
            ga_metric                      = self.ga_metric
            metric_descriptor              = ga_metric.MetricDescriptor()
            metric_descriptor.metric_kind  = ga_metric.MetricDescriptor.MetricKind.GAUGE  # CUMULATIVE too problematic
            metric_descriptor.value_type   = ga_metric.MetricDescriptor.ValueType.INT64 if is_int else ga_metric.MetricDescriptor.ValueType.DOUBLE
            metric_descriptor.type         = type
            metric_descriptor.unit         = unit
            metric_descriptor.display_name = display_name

            if description is not None:
                metric_descriptor.description = description

            # self.client_gcm.delete_metric_descriptor(name=f'{project_name}/metricDescriptors/{metric_descriptor.type}')
            self.client_gcm.create_metric_descriptor(name=project_name, metric_descriptor=metric_descriptor)

        except Exception as exc:  # because of 'google.api_core.exceptions.DeadlineExceeded: 504 Deadline expired before operation could complete.'
            logger.error(exc)

    def create_metrics(self, project_name):
        self.create_metric(project_name, 'custom.googleapis.com/filter/framerate/fps', '1/s', 'Framerate',
            'Frames per second processed by filter')
        self.create_metric(project_name, 'custom.googleapis.com/filter/cpu/utilization', '%', 'CPU',
            'Total system CPU utilization in percent')
        self.create_metric(project_name, 'custom.googleapis.com/filter/system/memory/used_gb', 'GiBy', 'Memory',
            'Filter process memory usage in GB')
        self.create_metric(project_name, 'custom.googleapis.com/filter/latency/ms', 'ms', 'Latency',
            'Filter latency in milliseconds')
        self.create_metric(project_name, 'custom.googleapis.com/filter/gpu/utilization', '%', 'GPU',
            'Total system GPU utilization in percent')
        self.create_metric(project_name, 'custom.googleapis.com/filter/gpu/memory/used_gb', 'GiBy', 'GPU Memory',
            'Total system GPU memory usage in GB')
        self.create_metric(project_name, 'custom.googleapis.com/filter/uptime/seconds', 's', 'Uptime',
            'Filter uptime in seconds', True, True)
        self.create_metric(project_name, 'custom.googleapis.com/filter/processed/frames', '1', 'Frames',
            'Number of frames processed by filter', True, True)
        self.create_metric(project_name, 'custom.googleapis.com/filter/processed/megapixels', '1', 'Megapixels',
            'Total megapixels processed by filter', False, True)

    def refresh_access_token(self):
        import google.auth as auth
        from google.auth.transport.requests import Request

        credentials, _ = auth.default(scopes=['https://www.googleapis.com/auth/cloud-platform'])

        credentials.refresh(Request())

        self.access_token = credentials.token

        return credentials.token

    @classmethod
    def normalize_config(cls, config: TelemetryGCConfig):
        config = TelemetryGCConfig(super().normalize_config(config))

        for coutput in config.outputs:
            coutput.output = output = coutput.output.rstrip('/')

            if output.startswith('gcm://'):
                if output.count('/') != 3:
                    raise ValueError(f"invalid gcm:// output {output!r}, must be of the form 'gcm://project_id/pipeline_id'")

            elif not output.startswith('gs://'):
                raise ValueError(f'only gs:// or gcm:// outputs allowed for this filter, not {output!r}')

        return config

    def setup(self, config: TelemetryGCConfig):
        self.outputs      = outputs    = {}  # {'output': OutputGCM | OutputGS, ...}
        self.client_gcm   = client_gcm = None
        self.client_gs    = client_gs  = None
        self.access_token = None
        project_names     = set()

        try:
            for coutput in config.outputs:
                if (output := coutput.output) in outputs:
                    continue

                if output.startswith('gs://'):
                    if client_gs is None:
                        from google.cloud import storage

                        self.client_gs = client_gs = storage.Client()

                    bucket, blobpath = output[5:].split('/', 1)

                    outputs[output] = TelemetryGC.OutputGS(bucket=client_gs.bucket(bucket), blobpath=blobpath)

                else:  # output.startswith('gcm://')
                    project_id, pipeline_id = output[6:].split('/')

                    outputs[output] = TelemetryGC.OutputGCM(project_name := f'projects/{project_id}', pipeline_id,
                        metric_types.copy())

                    for metry in m if (m := coutput.metries) is not None else [
                        TelemetryConfig.Output.Metry(logs=True, metrics=True)]:

                        if metry.logs:
                            if self.access_token is None:
                                self.refresh_access_token()  # we do this here so that bad credentials can show up right at startup

                        if metry.metrics:
                            if client_gcm is None:
                                from google.cloud import monitoring_v3
                                from google.api import metric_pb2 as ga_metric

                                self.monitoring_v3 = monitoring_v3
                                self.ga_metric     = ga_metric
                                self.client_gcm    = client_gcm = monitoring_v3.MetricServiceClient()

                            if project_name not in project_names:
                                project_names.add(project_name)

                                self.create_metrics(project_name)

            super().setup(config)

        except Exception:
            self.client_gs  = None
            self.client_gcm = None

            raise

    def shutdown(self):
        super().shutdown()

        self.client_gs  = None
        self.client_gcm = None  # why the @#&*$^ is there not an explicit close()

    def send(self, telemetry: dict[str, dict[tuple[str, LogCategory], Telemetry.Send]], closing: bool):
        client_gcm = self.client_gcm
        outputs    = self.outputs

        for output, sends in telemetry.items():
            if (output_gc := outputs.get(output)) is None:
                continue

            if output_gc.__class__ is TelemetryGC.OutputGS:
                bucket, blobname = output_gc

                for fid_n_cat, send in sends.items():
                    pos = False

                    try:
                        filter_id, category = fid_n_cat

                        data = [json_dumps(entry).encode() for entry, _ in send.entries]
                        pos  = None

                        if not data:
                            continue

                        dt0  = datetime.fromisoformat(json_loads(data[0].decode())['ts'])
                        fnm  = RollLog.filename(dt0, category, '.jsonl')
                        path = f'{blobname}/{filter_id}/{category}/{fnm}'

                        bucket.blob(path).upload_from_string(b'\n'.join(data))

                    except Exception as exc:
                        logger.error(exc)
                    finally:
                        send.end(pos)

            else:  # output_gc.__class__ is TelemetryGC.OutputGCM
                project_name = output_gc.project_name
                pipeline_id  = output_gc.pipeline_id
                metric_types = output_gc.metric_types

                for fid_n_cat, send in sends.items():
                    pos = False  # this will make send.end() rewind to start of data for resend attempt next time

                    try:
                        filter_id, category = fid_n_cat

                        if category == 'metrics':
                            monitoring_v3 = self.monitoring_v3
                            TimeInterval  = monitoring_v3.TimeInterval
                            TimeSeries    = monitoring_v3.TimeSeries
                            Point         = monitoring_v3.Point

                            for entry, pos in send.entries:
                                time_series = []
                                interval    = TimeInterval({'end_time': {
                                    'seconds': (s := int(t := datetime.fromisoformat(entry['ts']).timestamp())),
                                    'nanos':   int((t - s) * 1_000_000_000)
                                }})

                                for metric, value in entry.items():
                                    if metric == 'ts' or not isinstance(value, (int, float)):
                                        continue

                                    if (mtype_n_cls := metric_types.get(metric)) is not None:
                                        mtype, mcls = mtype_n_cls

                                    else:
                                        mtype, mcls = metric_types[metric] = (f'custom.googleapis.com/filter/user/{metric}', float)

                                        self.create_metric(project_name, mtype, '1', metric)

                                    series                              = TimeSeries()
                                    series.resource.type                = 'global'
                                    series.metric.type                  = mtype
                                    series.metric.labels['pipeline_id'] = pipeline_id
                                    series.metric.labels['filter_id']   = filter_id
                                    series.metric.labels['metric']      = metric
                                    series.points                       = [Point({'interval': interval, 'value':
                                        {'double_value': float(value)} if mcls is float else {'int64_value': int(value)}})]

                                    time_series.append(series)

                                client_gcm.create_time_series(name=project_name, time_series=time_series)

                            else:
                                pos = None  # send.end() leaves data at end to send new data next time

                        else:  # category == 'logs'
                            access_token = self.refresh_access_token()

                            utc     = timezone.utc
                            entries = [{
                                'textPayload': entry['msg'],
                                'severity':    entry['lvl'],
                                'timestamp':   datetime.fromisoformat(entry['ts']).astimezone(utc).isoformat(),
                            } for entry, _ in send.entries]

                            log = {
                                'logName':  f'{project_name}/logs/{pipeline_id}-{filter_id}',
                                'resource': {'type': 'global'},
                                'entries':  entries,
                            }

                            headers = {
                                'Authorization': f'Bearer {access_token}',
                                'Content-Type':  'application/json',
                            }

                            response = requests.post(f'https://logging.googleapis.com/v2/entries:write',
                                headers=headers, data=json_dumps(log))

                            if response.status_code == 200:
                                pos = None

                            else:
                                try:
                                    msg = f": {json_loads(response.text)['error']['message']}"
                                except Exception:
                                    msg = ''

                                logger.error(f'GCM send logs: {response.reason} ({response.status_code}){msg}')

                    except Exception as exc:
                        logger.error(exc)
                    finally:
                        send.end(pos)


if __name__ == '__main__':
    TelemetryGC.run()
