import logging
import os
import re
from json import loads as json_loads
from time import sleep
from threading import Event, Thread
from typing import Any, Callable, Generator, Iterable, Literal, NamedTuple

from ..filter import FilterConfig, Filter, POLL_TIMEOUT_SEC
from ..logging import LogCategory
from ..rolllog import RollLogPos, RollLog
from ..utils import JSONType, json_getval, sanitize_filename, dict_without, split_commas_maybe, once, adict

__all__ = ['TelemetryConfig', 'Telemetry']

logger = logging.getLogger(__name__)

TELEMETRY_PATH         = json_getval(os.getenv('TELEMETRY_PATH') or 'null')
TELEMETRY_INTERVAL     = float(os.getenv('TELEMETRY_INTERVAL') or 1800)
TELEMETRY_INTERVAL_MAX = float(os.getenv('TELEMETRY_INTERVAL_MAX') or 1800)
TELEMETRY_LINGER       = float(os.getenv('TELEMETRY_LINGER') or 3)

re_pat_all             = re.compile(r'^(?:.*)$')
re_plainsight          = re.compile(r'\bplainsight\b')
plainsight_metrics     = \
    'fps|cpu|mem|lat_in|lat_out|gpu0|gpu0_mem|gpu1|gpu1_mem|gpu2|gpu2_mem|gpu3|gpu3_mem|' \
    'gpu4|gpu4_mem|gpu5|gpu5_mem|gpu6|gpu6_mem|gpu7|gpu7_mem|uptime_count|frame_count|megapx_count|' \
    'dim_environment|dim_filter_runtime_version|dim_model_runtime_version|dim_filter_name|dim_filter_type|dim_filter_version'


logs_levels_included   = {
    True:       frozenset(('CRITICAL', 'ERROR', 'WARNING', 'INFO', 'DEBUG')),
    'DEBUG':    frozenset(('CRITICAL', 'ERROR', 'WARNING', 'INFO', 'DEBUG')),
    'INFO':     frozenset(('CRITICAL', 'ERROR', 'WARNING', 'INFO')),
    'WARNING':  frozenset(('CRITICAL', 'ERROR', 'WARNING')),
    'ERROR':    frozenset(('CRITICAL', 'ERROR')),
    'CRITICAL': frozenset(('CRITICAL',)),
    False:      frozenset(()),
}

merge_logs_levels = lambda l0, l1: (
    True if l0 in (True, 'DEBUG') or l1 in (True, 'DEBUG') else
    'INFO' if l0 == 'INFO' or l1 == 'INFO' else
    'WARNING' if l0 == 'WARNING' or l1 == 'WARNING' else
    'ERROR' if l0 == 'ERROR' or l1 == 'ERROR' else
    'CRITICAL')

merge_metrics_fields = lambda m0, m1: True if m0 is True or m1 is True else f'{m0}|{m1}'

sanitize_filename_w_wildcards_tbl = str.maketrans('<>:"\\\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f/', '_' * 38)

def sanitize_filename_w_wildcards(fnm: str) -> str:
    return fnm.translate(sanitize_filename_w_wildcards_tbl)

def re_wildcards(text: str) -> re.Pattern:
    """Compile a string pattern with '*', '?' and '|' (or) to a re.Pattern."""

    return re.compile('^(?:' + \
        '|'.join(  # prevents "|" from being re.escape()d
            '.*'.join(  # replaces "*"
                '.'.join(  # replaces "?"
                    re.escape(s) for s in p1.split('?')
                ) for p1 in p0.split('*')
            ) for p0 in text.split('|')
        ) + ')$')

def merge_metrics_field_and_pat(f0: str | bool, f1: re.Pattern | bool) -> re.Pattern | bool:
    if f0 is True or f1 is True:
        return True

    return re_wildcards('|'.join(sorted(set(s.strip() for s in f'{f0}|{f1.pattern[4 : -2]}'.split('|')))))


class TelemetryConfig(FilterConfig):
    class Output(adict):
        class Metry(adict):
            filter_id: str | None         # Filter config.id wildcard pattern ('*', '?' and '|' for or), None means all, spaces in str ignored
            logs:      str | bool | None  # whether to output logs, False means nothing, True means all, None means default (previous value in config or all if first)
            metrics:   str | bool | None  # metric name wildcard pattern, False means nothing, True means all, None means default (previous value in config or all if first)

        output:  str                 # output specifier, e.g. 'gcm://project_id/pipeline_id' or 'gs://customer_id/project_id/pipeline_id'
        metries: list[Metry] | None  # None means everything, yes 'metries' and not 'metrics', to differentiate, and shorter than 'telemetries'

    path:          str | Literal[False] | None  # dir to send logs and metrics from, specifically if is different from dir we write our own metry to, False to disable sending
    interval:      float | None
    interval_max:  float | None
    linger:        float | None
    extra_metrics: dict[str, JSONType] | list[tuple[str, JSONType]] | None

    outputs:       str | list[Output]


class Telemetry(Filter):
    """Telemetry base class. Takes care of watching log directories and periodically calling subclass to send data from
    Filter metries selected for output. Takes care of keeping track of what has been sent and picking up where it left
    off on subsequent runs if not everything was sent.

    config:
        outputs:
            These consist of subclass-specific addresses with semicolon separated standardized filter metry specifiers.
            What is shown below are just the semicolon specifiers of what to send to the subclass-specific destinations.

            ";myfilter" - All logs and metrics from filter 'myfilter'.

            ";myfilter/logs" - All logs from filter 'myfilter'.

            ";myfilter/logs.warning" - All warning or above logs from filter 'myfilter'.

            ";*/logs.error" - All error or above logs from filter ALL filters.

            ";myfilter/metrics" - All metrics from filter 'myfilter'.

            ";myfilter/metrics.plainsight" - All Plainsight metrics from filter 'myfilter'.

            ";myfilter/metrics.cpu|mem" - All 'cpu' or 'mem' metrics from filter 'myfilter'.

            ";my*/metrics.cpu|mem" - All 'cpu' or 'mem' metrics from all filters starting with 'my'.

            ";*suffix/metrics.custom*" - All metrics starting with 'custom' from all filters ending with 'suffix'.

            ";my*filter?/metrics.custom*|*special" - All metrics starting with 'custom' OR ending with 'special'
                from all filters starting with 'my' and ending with 'filter?' with a single character replacing the
                '?'.

        path:
            Path to telemetry logs and metrics to send, may be different from current LOG_PATH for this filter itself.
            Set to 'false' to disable sending.

        interval:
            Number of seconds between send attempts (if applicable). Global env var default TELEMETRY_INTERVAL.

        interval_max:
            Maximum number of seconds between send attempts after exponential backoff due to failures (if applicable).
            Global env var default TELEMETRY_INTERVAL_MAX.

        linger:
            How many seconds to linger on exit to try to catch last logs of other exiting filters. Global env var
            default TELEMETRY_LINGER.

        extra_metrics:
            A list of invariant tuples or dictionary of extra key/value pairs that will always be added to the metrics
            of EVERY filter whenever those are sent, meaning these can't be excluded with wildcards. Meant for
            "dimensions" for metrics.

    Environment variables:
        TELEMETRY_PATH
        TELEMETRY_INTERVAL
        TELEMETRY_INTERVAL_MAX
        TELEMETRY_LINGER

    Notes:
        * Any Telemetry* filter may or may not have other filter `sources`. The reason for having them is to plug in to
        the pipeline exit messages so that the Telemetry* filter exits when the whole pipeline exits. But it is not
        strictly necessary and the Telemetry* filter can either remain running and will pick up again the next time
        the pipeline is run or it can be terminated by docker if the whole pipeline is shut down explicitly (note that
        this does not happen if the pipeline exits natively by itself due to some filter exiting cleanly).
    """

    FILTER_TYPE = 'System'

    class Metry(NamedTuple):
        rlog: RollLog
        pat:  re.Pattern | str | Literal[True]  # metrics pat 'cpu|mem' or re or logs level 'INFO' or 'ERROR', etc...

    class Scan(NamedTuple):
        class Metry(NamedTuple):
            output:  str
            logs:    str | bool
            metrics: str | bool

        re_filter_fnm: re.Pattern
        metries:       list[Metry]

    class Send(NamedTuple):
        entries: Iterable[tuple[dict[str, JSONType], Any]]
        end:     Callable[[Any | None], None]  # call with None to indicate success otherwise the token from the `entries` iterator indicates first entry that could NOT be sent

    def scan(self):
        filters_scan  = self.filters_scan
        filters_found = self.filters_found

        for name in os.listdir(log_path := self.log_path):
            if name not in filters_found and os.path.isdir(filter_path := os.path.join(log_path, name)):
                has_logs    = os.path.isdir(logs_path := os.path.join(filter_path, 'logs'))
                has_metrics = os.path.isdir(metrics_path := os.path.join(filter_path, 'metrics'))
                new_logs    = has_logs and (key_logs := f'{name}/logs') not in filters_found
                new_metrics = has_metrics and (key_metrics := f'{name}/metrics') not in filters_found

                if not new_logs and not new_metrics:
                    continue

                if has_logs and has_metrics:
                    filters_found.add(name)

                if new_logs:
                    filters_found.add(key_logs)

                if new_metrics:
                    filters_found.add(key_metrics)

                outputs_metries = self.outputs_metries

                for scan in filters_scan:
                    if not scan.re_filter_fnm.match(name):
                        continue

                    for scan_metry in scan.metries:
                        if new_logs and (logs := scan_metry.logs):
                            if (metries := outputs_metries.get(output := scan_metry.output)) is None:
                                metries = outputs_metries[output] = {}

                            try:
                                rlog = RollLog(logs_path, 'bin', prefix='logs', suffix='.jsonl', rdonly=True,
                                    head=os.path.join(filter_path, f'head-{sanitize_filename(output)}-logs.json'))

                            except Exception as exc:
                                logger.error(exc)

                            else:
                                metries[key_metry] = (
                                    Telemetry.Metry(rlog, logs)
                                    if (metry := metries.get(key_metry := (name, 'logs'))) is None else
                                    Telemetry.Metry(metry.rlog, merge_logs_levels(logs, metry.pat))
                                )

                        if new_metrics and (metrics := scan_metry.metrics):
                            if (metries := outputs_metries.get(output := scan_metry.output)) is None:
                                metries = outputs_metries[output] = {}

                            try:
                                rlog = RollLog(metrics_path, 'bin', prefix='metrics', suffix='.jsonl', rdonly=True,
                                    head=os.path.join(filter_path, f'head-{sanitize_filename(output)}-metrics.json'))

                            except Exception as exc:
                                logger.error(exc)

                            else:
                                metries[key_metry] = (
                                    Telemetry.Metry(rlog, metrics if isinstance(metrics, bool) else re_wildcards(metrics))
                                    if (metry := metries.get(key_metry := (name, 'metrics'))) is None else
                                    Telemetry.Metry(metry.rlog, merge_metrics_field_and_pat(metrics, metry.pat))
                                )

    def scan_and_send(self, closing: bool = False):
        if self.log_path is False:
            return

        self.scan()

        telemetry = {}  # {output: {(filter_id, category): Send, ...}, ...}
        end_posss = {}  # {output: {(filter_id, category): RollLogPos | None, ...}, ...}

        for output, metries in self.outputs_metries.items():
            for key_fc, metry in metries.items():
                try:
                    if (block := (rlog := metry.rlog).read_block()) is None:
                        continue

                except Exception as exc:
                    once(logger.error, exc, t=60*15)

                    continue

                fnm, pos  = rlog.tell()  # TODO: this can error due to file.tell() in RollLog.tell()
                pos      -= len(block)

                if (sends := telemetry.get(output)) is not None:
                    end_poss = end_posss[output]
                else:
                    end_poss = end_posss[output] = {}
                    sends    = telemetry[output] = {}

                def closure_entries(rlog, category, pat, block, fnm, pos):
                    def generator(block, fnm, pos) -> Generator[tuple[dict[str, JSONType], Any], None, None]:  # first entry is actual entry, second is position token to return for on error sending this
                        while True:  # first iteration is always valid
                            block = block.split(b'\n')[:-1]  # last one is a b'' because of trailing newline

                            if category == 'logs':
                                logs_levels = logs_levels_included[pat]

                                for entry in block:
                                    if (jentry := json_loads(entry.decode()))['lvl'] in logs_levels:
                                        yield (jentry, (fnm, pos))

                                    pos += len(entry) + 1

                            else:  # category == 'metrics'
                                extra_metrics = self.extra_metrics

                                for entry in block:
                                    jentry = json_loads(entry.decode())

                                    if pat is True:
                                        yield ({**jentry, **extra_metrics} if extra_metrics else jentry, (fnm, pos))

                                    elif metrics := {k: v for k, v in jentry.items() if pat.match(k)}:
                                        metrics['ts'] = jentry['ts']  # 'ts' tells u when it happened, it must be present

                                        if len(metrics) != 1:  # because 'ts' could still be the only thing in there and we don't want to send just that alone
                                            yield ({**metrics, **extra_metrics} if extra_metrics else metrics, (fnm, pos))

                                    pos += len(entry) + 1

                            try:
                                if (block := rlog.read_block()) is None:
                                    break

                            except Exception as exc:
                                once(logger.error, exc, t=60*15)

                                break

                            fnm, _ = rlog.tell(False)  # just need the filename
                            pos    = 0                 # will be 0 because we just did a read_block at end of file so a whole new file was read

                    return generator(block, fnm, pos)

                def closure_end(end_poss, key_fc):
                    def end(end_pos: RollLogPos | Literal[False] | None = None):
                        if end_pos is not False:
                          end_poss[key_fc] = end_pos

                    return end

                end_poss[key_fc] = (fnm, pos)
                sends[key_fc]    = Telemetry.Send(
                    closure_entries(rlog, key_fc[1], metry.pat, block, fnm, pos),
                    closure_end(end_poss, key_fc)
                )

        try:
            logger.debug('send telemetry')

            self.send(telemetry, closing)

        finally:
            outputs_metries = self.outputs_metries

            for output, end_poss in end_posss.items():
                metries = outputs_metries[output]

                for fid_n_cat, pos in end_poss.items():
                    rlog = metries[fid_n_cat].rlog

                    if pos is not None:  # rewind in case of error
                        rlog.seek(pos)

                    rlog.write_head(pos)  # update current position

    def thread_func(self):
        interval_cur = min(5, self.interval_cur)  # first wait short so we can send first bit of log as soon as possible

        while not self.stop_evt.wait(interval_cur):
            self.scan_and_send()

            interval_cur = self.interval_cur

        self.scan_and_send(True)

    @classmethod
    def normalize_config(cls, config: TelemetryConfig):
        outputs = split_commas_maybe(config.get('outputs'))
        config  = TelemetryConfig(super().normalize_config(dict_without(config, 'outputs')))

        if not outputs:
            raise ValueError('must specify at least one output')

        new_outputs = []

        for output in outputs:
            if not isinstance(output, str):
                new_output = output

            else:
                new_output, metries = Filter.parse_topics(output, mapping=False, default_topic='')
                new_output          = TelemetryConfig.Output(output=new_output)

                if metries:
                    new_output.metries = new_metries = []

                    for metry in metries:
                        if not metry:
                            raise ValueError(f'empty filter id in telemetry output {output!r}')

                        filter_id, *metries = [s.strip() for s in metry.split('/')]
                        metry               = TelemetryConfig.Output.Metry(filter_id=filter_id)

                        if not metries:
                            metry.logs = metry.metrics = True

                        for me in metries:
                            m, *fields = [s.strip() for s in me.split('.')]

                            if len(fields) > 1:
                                raise ValueError(f"multiple field '.' delimiters {me!r} in in telemetry output {output!r}")
                            elif len(fields) == 1 and fields[0] == '':
                                raise ValueError(f"empty field '.' {me!r} in in telemetry output {output!r}")

                            if m == 'logs':
                                metry.logs = lvl = True if not fields else fields[0].upper()

                                if lvl not in (True, 'DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'):
                                    raise ValueError(f'invalid logging level {lvl!r} in telemetry output {output!r}')

                            elif m == 'metrics':
                                metry.metrics = True if not fields else '|'.join(s.strip() for s in fields[0].split('|'))
                            else:
                                raise ValueError(f'invalid metry category {me!r} in telemetry output {output!r}')

                        new_metries.append(metry)

            new_outputs.append(new_output)

        config.outputs = new_outputs

        if (extra_metrics := config.extra_metrics) is not None:
            if isinstance(extra_metrics, list):
                config.extra_metrics = dict(extra_metrics)
            elif not isinstance(extra_metrics, dict):
                raise ValueError(f'invalid extra_metrics {extra_metrics!r}, must be list or dict of key/value pairs')

        return config

    def init(self, config):
        if self.__class__ is Telemetry:
            raise RuntimeError('Telemetry Filter is meant to be subclassed, not run standalone')

        super().init(FilterConfig(config, outputs=None))

    def setup(self, config: TelemetryConfig):
        self.log_path      = log_path = p if (p := p if (p := config.path) is not None else \
            TELEMETRY_PATH if TELEMETRY_PATH is not None else self.logger.log_path) is False else os.path.abspath(p)  # 'self.logger' comes from Filter base class
        self.interval      = TELEMETRY_INTERVAL if config.interval is None else config.interval
        self.interval_max  = TELEMETRY_INTERVAL_MAX if config.interval_max is None else config.interval_max
        self.linger        = TELEMETRY_LINGER if config.linger is None else config.linger
        self.extra_metrics = config.extra_metrics

        filters_scan = {}  # {re_filter_fnm: {'output': (logs: bool, metrics: set[str] | bool), ...}, ...}  - metrics fields created from multiple patterns, 'a|b' + 'c*' -> 'a|b|c*'

        if log_path is not False:
            if not os.path.isdir(log_path):
                raise ValueError(f'invalid log path {log_path!r}')

            for coutput in config.outputs:  # convert config specification to directory filters_scan specification
                for metry in m if (m := coutput.metries) is not None else [TelemetryConfig.Output.Metry()]:
                    re_filter_fnm = re_pat_all if (filter_id := metry.filter_id) is None else \
                        re_wildcards(sanitize_filename_w_wildcards(filter_id))

                    if (outputs := filters_scan.get(re_filter_fnm)) is None:
                        outputs = filters_scan[re_filter_fnm] = {}

                    if (logs_n_metrics := outputs.get(output := coutput.output)) is None:
                        if (logs := metry.logs) is None:
                            logs = metry.metrics is None

                        if (metrics := metry.metrics) is None:
                            metrics = metry.logs is None

                    else:
                        if (logs := metry.logs) is None:
                            logs = logs_n_metrics[0]
                        elif isinstance(logs, str) and (old_logs := logs_n_metrics[0]) is not False:
                            logs = merge_logs_levels(logs, old_logs)

                        if (metrics := metry.metrics) is None:
                            metrics = logs_n_metrics[1]
                        elif isinstance(metrics, str) and (old_metrics := logs_n_metrics[1]) is not False:
                            metrics = merge_metrics_fields(metrics, old_metrics)

                    outputs[output] = (logs, metrics)

        self.outputs_metries = {}  # {'output': {(filter_id, category): Metry, ...}, ...}
        self.filters_found   = set()

        self.filters_scan  = [
            Telemetry.Scan(re_filter_fnm, [
                Telemetry.Scan.Metry(output, logs,
                    metrics if isinstance(metrics, bool) else re_plainsight.sub(plainsight_metrics, metrics)
                ) for output, (logs, metrics) in scan_metries.items()
            ]) for re_filter_fnm, scan_metries in filters_scan.items()
        ]

        self.interval_cur = self.interval
        self.sleep        = 0 if config.sources else POLL_TIMEOUT_SEC
        self.stop_evt     = Event()
        self.thread       = Thread(target=self.thread_func, daemon=True)

        self.thread.start()

    def shutdown(self):
        sleep(self.linger)

        self.stop_evt.set()
        self.thread.join()

        for metries in self.outputs_metries.values():
            for metry in metries.values():
                try:
                    metry.rlog.close()
                except Exception as exc:
                    logger.error(exc)

    def process(self, frames):
        sleep(self.sleep)  # this exists so we don't spin infinitely fast if there are no 'sources' to pace us

    def send(self, telemetry: dict[str, dict[tuple[str, LogCategory], 'Telemetry.Send']], closing: bool):
        """Send data to specific telemetry destination. This must be overloaded in specific telemetry subclass.

        Args:
            telemetry: Dictionary indexed by config output base (before the semicolons) which itself is indexed by a
                tuple of (fitler_id, 'logs' or 'metrics') of Telemetry.Send objects. Each object has an `entries` member
                which is an Iterable to get the (entry, pos) of each entry to be sent in chronologicalk order. There is
                also an `end()` method which can be called with a single argument of None to indicate that all entries
                were sent successfully, False to indicate that no entries were sent (logs will be rewound and attempted
                again on next send) or a position from the `entries` Iterable which will indicate the first entry which
                could NOT be sent (in which case next call will start at this entry).

            closing: True if this is the last cleanup send, meant to inform not to wait on a reconnect or the like, send
                what can be sent of last data and shut down whatever need to be shut down at this point, the rest in
                shutdown().

        Notes:
            * The subclass can manipulate `self.interval_cur` in case it needs to back off on sending.
        """

        raise NotImplementedError('this method is meant to be overloaded in a subclass')


if __name__ == '__main__':
    Telemetry.run()  # although this will fail because Telemetry is supposed to be subclassed
