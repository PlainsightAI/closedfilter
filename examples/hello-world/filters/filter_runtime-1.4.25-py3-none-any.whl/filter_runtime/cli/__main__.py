import sys

from .common import SCRIPT
from .cmd_logs_metrics import cmd_logs, cmd_metrics
from .cmd_info import cmd_info
from .cmd_run import cmd_run
from .cmd_compose import cmd_compose


def main():
    args = sys.argv[2:]
    cmd  = sys.argv[1] if len(sys.argv) > 1 else ''

    if cmd_func := getattr(sys.modules[__name__], f'cmd_{cmd}', None):
        cmd_func(args)

    else:
        print(f"""
usage: {SCRIPT} COMMAND ...

Commands:
  run       Directly run one or more filter(s)
  compose   Convert "run" parameters to a docker-compose.yaml (approximation).
  logs      Show filter(s) logs
  metrics   Show filter(s) metrics
  info      Get help on a specific filter

Run '{SCRIPT} COMMAND --help' for more information on a command.
""".strip())


if __name__ == '__main__':
    main()
