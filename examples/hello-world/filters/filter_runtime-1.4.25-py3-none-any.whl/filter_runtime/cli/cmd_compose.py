import argparse
import importlib
import json
import logging
import os
import re

from ..utils import split_commas_maybe, pascal_to_snake_case, levenshteinish_distance, setLogLevelGlobal

from .common import SCRIPT, DOCKER_IMAGES, only_mq_addr, parse_filters

logger = logging.getLogger(__name__)

logger.setLevel(int(getattr(logging, (os.getenv('LOG_LEVEL') or 'INFO').upper())))


# --- compose ----------------------------------------------------------------------------------------------------------

def cmd_compose(args):
    try:
        idx = args.index('-')
    except ValueError:
        idx = len(args)

    opts   = args[:idx]
    parser = argparse.ArgumentParser(prog=f'{SCRIPT} run', formatter_class=argparse.RawTextHelpFormatter,
        usage=f"""
usage: {SCRIPT} compose [--ipc] [--version VERSION] [-r RUNTIME_VERSION] [-v] FILTER [FILTER ...]
        """.strip(),
        description="""
Convert "run" parameters to a docker-compose.yaml (approximation).

positional arguments:
  FILTER                specified as "- package.filter.Filter [--config_param value ...]"
        """.strip()
    )

    parser.add_argument('--ipc',
        action = 'store_true',
        help   = 'when creating new connections make them ipc:// instead of tcp://',
    )
    parser.add_argument('--version',
        type = str,
        help = 'current project version',
    )
    parser.add_argument('-r', '--runtime-version',
        type = str,
        help = 'filter_runtime docker images version',
    )
    parser.add_argument('-v', '--verbose',
        action = 'store_true',
        help   = 'output more information',
    )

    opts = parser.parse_args(opts)

    if not opts.verbose:
        setLogLevelGlobal(logging.ERROR)

    logger.debug(f'opts: {opts}')

    # parse filters

    filters = parse_filters(args[:idx:-1], opts.ipc)

    # build compose

    def ipc_fnm(ipc: str) -> str:
        return f'ipc/{os.path.normpath(ipc).replace("../", "___").replace("/", "_")}'

    def mq_path(addr: str) -> str | tuple[int | str] | None:  # expects only_mq_addr() processed addr, no '?', ';' or '!' stuff, returns tcp host and port, ipc fnm or None if not tcp:// or ipc://
        path = addr[6:]

        if addr.startswith('ipc://'):
            return path

        elif addr.startswith('tcp://'):
            try:
                host, port = path.rsplit(':', 1)

                return host, int(port)

            except Exception:
                return path, 5550

        return None

    def map_file(uri: str, volumes: dict) -> str:
        if (fnm := os.path.normpath(uri[7:])).startswith('/'):  # absolute path
            volumes[dir] = f'/rootdir{(dir := os.path.split(fnm)[0]).rstrip("/")}'

            return f'file:///rootdir{fnm}'

        elif fnm.startswith('../'):  # relative path going up
            dir          = os.path.split(fnm)[0]
            volumes[dir] = f'/curdir/{os.path.split(fnm := fnm.replace("../", "__/"))[0]}'

            return f'file:///curdir/{fnm}'

        else:  # relative path here or down
            volumes[f'./{dir}' if dir else '.'] = f'/curdir{f"/{dir}" if (dir := os.path.split(fnm)[0]) else ""}'

            return f'file:///curdir/{fnm}'

    if not (version := opts.version) and not (version := os.getenv('VERSION') or None):
        try:
            with open('VERSION') as f:
                if len(lines := f.read().strip().split('\n')) == 1:
                    version = lines[0]

        except Exception:
            pass

    if not (runtime_version := opts.runtime_version):
        runtime_version = None

        try:
            with open('pyproject.toml') as f:
                if m := re.search(r'"filter_runtime==([^"\n]+)"', f.read()):
                    runtime_version = m.group(1)

        except Exception:
            pass

        if runtime_version is None:
            runtime_version = '1.4.9'

            logger.warning(f'could not determine runtime version, using {runtime_version}')

    images   = {full_filter_name: f'{img}:{runtime_version}' for full_filter_name, img in DOCKER_IMAGES.items()}
    outs_map = {}  # {tcp_port | 'ipc_fnm': config, ...}

    # zeroth pass, if IMAGE from env var or Makefile then assign it to closest name unknown filter

    if (image := os.getenv('IMAGE')) is None:
        try:
            with open('Makefile') as f:
                if m := re.search(r'^IMAGE\s+(?:=|:=|\?=|!=)\s+([^\s\n]+)$', f.read(), re.MULTILINE):
                    image = m.group(1)

        except Exception:
            pass

    if image is not None:
        unknowns = set()

        for cls, _, _ in filters:
            if (full_name := f'{cls.__module__}.{cls.__qualname__}') not in images:
                unknowns.add(full_name)

        if unknowns:
            unknowns = [(levenshteinish_distance(image, u), u) for u in unknowns]

            unknowns.sort()

            guess = unknowns[0][1]

            if len(unknowns) > 1:
                logger.warning(f'more than one unknown filter with image available, guessing the image {image!r} belongs to {guess!r}')
            if version is None:
                logger.warning(f"could not determine project version, using 'latest'")

            images[guess] = f'{image}:{version or "latest"}'

    # first pass, set defaults and build outputs map

    for cls, config, name in filters:
        full_name            = f'{cls.__module__}.{cls.__qualname__}'
        config.__id          = pascal_to_snake_case(name)
        config.__image       = images.get(full_name) or '<UNKNOWN DOCKER IMAGE>'
        config.__jfrog_token = False
        config.__env         = config.get('__env_compose') or {}
        config.__ports       = ports   = []
        config.__gpu         = False
        config.__volumes     = volumes = {
            './cache':     '/app/cache',
            './telemetry': '/app/telemetry',
        }

        if full_name in ('filter_runtime.filters.rest.REST', 'filter_runtime.filters.webvis.Webvis'):  # default expose port 8000
            ports.append(8000)

        stack = [(config, key) for key in config if not key.startswith('_')]

        while stack:  # process URIs, jfrog:// add JFROG_TOKEN, file:// add mapping to volumes
            parent, key = stack.pop()
            obj         = parent.__getitem__(key)

            if isinstance(obj, (list, tuple)):
                stack.extend([(obj, idx) for idx in range(len(obj))])
            elif isinstance(obj, dict):
                stack.extend([(obj, key) for key in obj])

            elif isinstance(obj, str) and key not in ('sources', 'outputs'):
                if obj.startswith('jfrog://'):
                    config.__jfrog_token = True
                if obj.startswith('file://'):
                    parent.__setitem__(key, map_file(obj, volumes))

        try:  # add GPU if package has any resources which use GPU
            deps = importlib.metadata.distribution(full_name.split('.', 1)[0]).metadata.get_all('Requires-Dist')
        except Exception as exc:
            logger.warning(exc)
        else:
            config.__gpu = any(s.startswith('protege-runtime ') or s.startswith('torch ') or s.startswith('torchvision ')
                for s in deps)

        if outputs := config.outputs:  # add output tcp:// port and ipc:// files to map
            for idx, output in enumerate(outputs := split_commas_maybe(outputs)):
                if isinstance(res := mq_path(output), str):  # ipc://
                    outs_map[res]    = config
                    volumes['./ipc'] = '/app/ipc'
                    outputs[idx]     = f'ipc://{ipc_fnm(res)}'

                elif res is not None:  # tcp://
                    host, port = res

                    if host in ('*', '0', '0.0.0.0'):
                        outs_map[port] = config

                    elif host == 'localhost' or host.startswith('127.'):
                        outs_map[port] = config
                        outputs[idx]   = f'tcp://{config.__id}:{port}'

                elif output.startswith('file://'):
                    outputs[idx] = map_file(output, volumes)

            config.outputs = ', '.join(outputs)

    # second pass, remap sources to container names

    for _, config, _ in filters:
        if sources := config.sources:
            for idx, source in enumerate(sources := split_commas_maybe(sources)):
                if (source_ := only_mq_addr(source)).startswith('jfrog://'):
                    config.__jfrog_token = True

                elif isinstance(res := mq_path(source_), str):  # ipc://
                    config.__volumes['./ipc'] = '/app/ipc'
                    sources[idx]              = f'ipc://{ipc_fnm(res)}{source[len(source_):]}'

                elif res is not None:  # tcp://
                    host, port = res

                    if (host == 'localhost' or host.startswith('127.')) and (out_config := outs_map.get(port)):
                        sources[idx] = f'tcp://{out_config.__id}:{port}{source[len(source_):]}'

                elif source_.startswith('file://'):
                    sources[idx] = f'{map_file(source_, config.__volumes)}{source[len(source_):]}'

            config.sources = ', '.join(sources)

    # print compose

    def yamlstr(s):  # TODO: handle lists and dicts properly
        return json.dumps(s) if not isinstance(s, str) or s.endswith(' ') or any(ord(c) < 32 for c in s) else s

    def envvar(name, value='', indent='      ', env=False):
        if env:
            return f'{indent}{name}: ${{{name if env is True else env}:-{yamlstr(value) if value != "" else ""}}}'
        else:
            return f'{indent}{name}: {yamlstr(value)}'

    print('services:')

    for cls, config, name in filters:
        print(f'  {config.__id}:')
        print(f'    image: {config.__image}')
        print( '    environment:')
        print(envvar('LOG_LEVEL', env=True))

        if config.__jfrog_token:
            print(envvar('JFROG_TOKEN', env=True))

        for param, value in config.items():
            if not param.startswith('__'):
                print(envvar(f'FILTER_{param.upper()}', value))

        for var, value in config.__env.items():
            print(envvar(f'{var}', value))

        if config.__gpu:
            print('    deploy:')
            print('      resources:')
            print('        reservations:')
            print('          devices:')
            print('            - driver: nvidia')
            print('              count: all')
            print('              capabilities: [gpu]')

        if config.__volumes:
            print('    volumes:')

            for src, dst in config.__volumes.items():
                print(f'      - {src}:{dst}')

        if config.__ports:
            print('    ports:')

            for port in config.__ports:
                print(f'      - {port}:{port}')

        print('    networks:')
        print('      - filter-network')

        print()

    print('networks:')
    print('  filter-network:')
