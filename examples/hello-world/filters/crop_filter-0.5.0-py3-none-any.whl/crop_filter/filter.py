import logging
import cv2
import numpy as np
import ast
from filter_runtime.filter import FilterConfig, Filter, Frame
from typing import List, Tuple
import os

__all__ = ['CropFilterConfig', 'CropFilter']

logger = logging.getLogger(__name__)

SKIP_OCR_FLAG = 'skip_ocr'

class CropFilterConfig(FilterConfig):
    polygon_points: str = "[[(854, 201), (1377, 208), (1387, 266), (859, 259)]]" 
    crop_from_env: bool = False
    mutate_original_frames: bool = False
    cropped_frame_prefix: str = "cropped_"



class CropFilter(Filter):
    """Crop filter is used for cropping video as per polygon coordinates and generating a new video"""

    @classmethod
    def normalize_config(cls, config: CropFilterConfig):
        config = CropFilterConfig(super().normalize_config(config))

        env_mapping = {
            "mutate_original_frames": bool,
            "cropped_frame_prefix": str,
            "crop_from_env": bool,
        }

        for key, expected_type in env_mapping.items():
            env_key = f"FILTER_{key.upper()}"
            env_val = os.getenv(env_key)
            if env_val is not None:
                if expected_type is bool:
                    setattr(config, key, env_val.strip().lower() == "true")
                else:
                    setattr(config, key, env_val.strip())


        # Convert polygon_points from string to list if it is a string
        if isinstance(config.polygon_points, str):
            config.polygon_points = ast.literal_eval(config.polygon_points)

            if len(config.polygon_points[0]) < 3:
                raise ValueError("Polygon must have at least three vertices.")
        else:
            # Assume it will come from mqtt
            config.polygon_points = None

        if not config.mutate_original_frames and not config.cropped_frame_prefix:
            raise ValueError("cropped_frame_prefix cannot be empty when mutate_original_frames is False.")

        return config

    def setup(self, config: CropFilterConfig):
        """Setup method where initializations occur"""
        logger.info("===========================================")
        logger.info(f"FilterPolygonCrop setup: {config}")
        logger.info("===========================================")

        self.crop_from_env = config.crop_from_env
        self.skip_ocr = False
        self.mutate_original_frames = config.mutate_original_frames
        self.cropped_frame_prefix = config.cropped_frame_prefix

        if config.polygon_points is None:
            self.polygon_points = None
        else:
            self.polygon_points = np.array(config.polygon_points, dtype=np.int32)
            
            # Compute bounding box around the polygon for crop dimensions
            # self.x, self.y, self.w, self.h = cv2.boundingRect(self.polygon_points)
            self.x, self.y, self.w, self.h = self.polygon_to_bbox(self.polygon_points)
                
        logger.info("Setup Completed for Crop Filter")


    def shutdown(self):
        logger.info("Shutdown completed!")


    def process(self, frames: dict[str, Frame]):
        output_frames = {**frames} if not self.mutate_original_frames else frames

        for topic, frame in frames.items():
            image = frame.rw_bgr.image
            frame_count = frame.data["meta"]["id"]

            # Cropping logic...
            if "polygons" in frame.data['meta'] and frame.data['meta']["polygons"] is not None:
                self.polygon_points = np.array(frame.data['meta']["polygons"][0], dtype=np.int32)
                self.x, self.y, self.w, self.h = self.polygon_to_bbox(self.polygon_points)

                mask = np.zeros_like(image, dtype=np.uint8)
                cv2.fillPoly(mask, [self.polygon_points], (255, 255, 255))
                masked_frame = cv2.bitwise_and(image, mask)
                cropped_frame = masked_frame[self.y:self.y + self.h, self.x:self.x + self.w]

                frame.data['meta'][SKIP_OCR_FLAG] = False

            elif self.crop_from_env:
                mask = np.zeros_like(image, dtype=np.uint8)
                cv2.fillPoly(mask, [self.polygon_points], (255, 255, 255))
                masked_frame = cv2.bitwise_and(image, mask)
                cropped_frame = masked_frame[self.y:self.y + self.h, self.x:self.x + self.w]
            else:
                cropped_frame = image
                frame.data['meta'][SKIP_OCR_FLAG] = True

            if self.mutate_original_frames:
                frame.rw_bgr.image = cropped_frame
            else:
                output_frames[self.cropped_frame_prefix + topic] = Frame(cropped_frame, {**frame.data}, 'BGR')

        return output_frames

    @classmethod
    def polygon_to_bbox(cls, polygon_points: List[Tuple[int, int]]) -> Tuple[int, int, int, int]:
        """
        Convert a list of polygon points to a bounding box.
        Args:
            polygon_points (list of tuples): A list of (x, y) tuples representing the vertices of the polygon.
        Returns:
            tuple: A tuple (x, y, w, h) where (x, y) is the top-left corner of the bounding box,
                   and (w, h) are the width and height of the bounding box, respectively.
        """
        """Convert polygon points to bounding box"""
        x, y, w, h = cv2.boundingRect(polygon_points)
        
        return x, y, w, h


if __name__ == '__main__':
    CropFilter.run()
